#pragma once
#include <iostream>
#include "MyString.h"
using namespace std;

class MyStringIdentifier : public MyString
{

};

